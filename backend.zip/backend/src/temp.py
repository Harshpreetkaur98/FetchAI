
import json
import os

def process_employee_record(employee):
    receiving_pension = employee['status'] == 'pensioner'
    
    if receiving_pension:
        years_left = -1
    else:
        current_age = employee['age']
        if employee['gender'] == 'Male':
            normal_retirement_age = 65
        else:
            normal_retirement_age = 60
        
        if employee['tenure'] >= 30 and current_age >= (60 if employee['gender'] == 'Female' else 65):
            years_left = 0
        elif employee['tenure'] < 30:
            years_left = 65 - current_age
        else:
            years_left = normal_retirement_age - current_age

    inflationary_increase = 7.5 if employee['tenure'] >=30 else 3.0
    
    if employee['married']:
        pension_percentage_after_death = 50
    else:
        pension_percentage_after_death = 0
    
    disability_increase = 0
    if employee['incapacitated']:
        disability_increase = 5
    
    return {
        'id': employee['id'],
        'receiving_pension': receiving_pension,
        'years_left': years_left,
        'inflationary_increase': inflationary_increase,
        'pension_percentage_after_death': pension_percentage_after_death,
        'disability_increase': disability_increase,
    }

def main():
    script_dir = os.path.dirname(__file__)
    input_path = os.path.join(script_dir, "data", "data.json")
    output_path = os.path.join(script_dir, "data", "processed_data.json")
    
    with open(input_path, 'r') as f:
        employees = json.load(f)
    
    processed_employees = [process_employee_record(emp) for emp in employees]
    
    with open(output_path, 'w') as f:
        json.dump(processed_employees, f, indent=4)

if __name__ == "__main__":
    main()
